# حل مشكلة تسجيل الدخول - دليل شامل

## 📋 ملخص المشكلة

عند محاولة تسجيل الدخول على:
```
https://build-production-09b2.up.railway.app/login
```

باستخدام البيانات:
- البريد الإلكتروني: `waleed.qodami@gmail.com`
- كلمة المرور: `3505490qwE@@`

تظهر رسالة الخطأ: **"بيانات تسجيل الدخول غير صحيحة"**

## 🔍 السبب

المستخدم الافتراضي (admin) **غير موجود** في قاعدة البيانات على Railway. لم يتم تشغيل seed script بعد النشر.

## ✅ الحلول المتاحة

### الحل 1: استخدام Railway CLI (الأسرع والأسهل) ⭐

#### الخطوات:

1. **تثبيت Railway CLI**
   ```bash
   npm install -g @railway/cli
   ```

2. **تسجيل الدخول**
   ```bash
   railway login
   ```

3. **الانتقال إلى مجلد المشروع**
   ```bash
   cd /path/to/build
   ```

4. **ربط المشروع**
   ```bash
   railway link
   ```
   اختر المشروع الصحيح من القائمة.

5. **تشغيل seed script**
   ```bash
   railway run npx tsx server/seed-admin-pg.ts
   ```

6. **التحقق من النجاح**
   يجب أن ترى:
   ```
   ✅ Admin created successfully!
   Email: waleed.qodami@gmail.com
   Password: 3505490qwE@@
   ```

7. **اختبار تسجيل الدخول**
   افتح المتصفح وانتقل إلى صفحة تسجيل الدخول وجرب البيانات.

---

### الحل 2: استخدام Neon SQL Editor (إذا لم يعمل Railway CLI)

#### الخطوات:

1. **افتح Neon Dashboard**
   - انتقل إلى: https://neon.tech
   - سجل الدخول إلى حسابك
   - اختر قاعدة البيانات الخاصة بالمشروع

2. **افتح SQL Editor**
   - في لوحة التحكم، اختر "SQL Editor"

3. **نفذ SQL Script**
   انسخ والصق هذا الكود:
   
   ```sql
   INSERT INTO admins (email, password_hash, name, role, is_active, created_at, updated_at)
   VALUES (
     'waleed.qodami@gmail.com',
     '$2b$12$5yg5UHGdqI50fmZlRD5Tbejd5boNtp/cgIvQxob.eHnpSuLHOL7EK',
     'Waleed Qodami',
     'super_admin',
     1,
     NOW(),
     NOW()
   )
   ON CONFLICT (email) DO NOTHING;
   ```

4. **تحقق من النجاح**
   قم بتشغيل:
   ```sql
   SELECT id, email, name, role, is_active 
   FROM admins 
   WHERE email = 'waleed.qodami@gmail.com';
   ```

5. **اختبر تسجيل الدخول**
   افتح المتصفح وجرب تسجيل الدخول.

**ملاحظة:** الملف `create-admin-user.sql` يحتوي على هذا الكود جاهزاً.

---

### الحل 3: تحديث عملية النشر (حل دائم للمستقبل)

لتجنب هذه المشكلة في المستقبل، قم بأحد هذين الخيارين:

#### الخيار أ: تعديل package.json

أضف script لتشغيل seed تلقائياً:

```json
{
  "scripts": {
    "start": "NODE_ENV=production node dist/index.js",
    "seed": "npx tsx server/seed-admin-pg.ts || true",
    "postbuild": "npm run seed"
  }
}
```

#### الخيار ب: تعديل railway.json

```json
{
  "build": {
    "builder": "DOCKERFILE"
  },
  "deploy": {
    "startCommand": "npx tsx server/seed-admin-pg.ts || true && npm start"
  }
}
```

بعد التعديل، قم بـ commit و push:
```bash
git add .
git commit -m "Add automatic admin seeding on deployment"
git push origin main
```

---

## 🧪 التحقق من نجاح الحل

بعد تطبيق أي من الحلول أعلاه:

1. افتح المتصفح
2. انتقل إلى: https://build-production-09b2.up.railway.app/login
3. أدخل البيانات:
   - البريد الإلكتروني: `waleed.qodami@gmail.com`
   - كلمة المرور: `3505490qwE@@`
4. يجب أن تنجح عملية تسجيل الدخول وتنتقل إلى `/admin`

---

## 🔧 استكشاف الأخطاء

### خطأ: "DATABASE_URL is required"
**الحل:** تأكد من أن متغير البيئة `DATABASE_URL` موجود في Railway:
1. افتح مشروعك في Railway
2. اذهب إلى Variables
3. تحقق من وجود `DATABASE_URL`

### خطأ: "Connection refused" أو "Connection timeout"
**الحل:** قاعدة بيانات Neon قد تكون متوقفة:
1. افتح Neon Dashboard
2. تحقق من حالة قاعدة البيانات
3. إذا كانت متوقفة، قم بتفعيلها

### خطأ: "Table 'admins' doesn't exist"
**الحل:** لم يتم تشغيل migrations:
```bash
railway run pnpm drizzle-kit push
```

### المستخدم موجود لكن لا يمكن تسجيل الدخول
**الحل:** قد تكون كلمة المرور خاطئة. احذف المستخدم وأعد إنشاءه:
```sql
DELETE FROM admins WHERE email = 'waleed.qodami@gmail.com';
-- ثم أعد تشغيل INSERT statement
```

---

## 📁 الملفات المساعدة

تم إنشاء الملفات التالية لمساعدتك:

1. **`create-admin-user.sql`** - SQL script جاهز للتنفيذ في Neon
2. **`generate-hash.cjs`** - script لتوليد password hash جديد إذا احتجت
3. **`QUICK_FIX.md`** - دليل سريع مختصر
4. **`login_issue_notes.md`** - ملاحظات تفصيلية عن المشكلة

---

## 📞 الدعم

إذا استمرت المشكلة بعد تطبيق جميع الحلول:

1. تحقق من Railway logs:
   ```bash
   railway logs
   ```

2. تحقق من اتصال قاعدة البيانات:
   ```bash
   railway run npx tsx -e "import('postgres').then(p => p.default(process.env.DATABASE_URL).query('SELECT 1'))"
   ```

3. تحقق من وجود المستخدم في قاعدة البيانات:
   ```bash
   railway run npx tsx -e "import('./server/auth.js').then(a => a.getAdminByEmail('waleed.qodami@gmail.com').then(console.log))"
   ```

---

## ✨ الخلاصة

**الحل الموصى به:** استخدم Railway CLI (الحل 1) لأنه الأسرع والأكثر موثوقية.

**الوقت المتوقع:** 5-10 دقائق

**مستوى الصعوبة:** سهل ⭐

بعد تطبيق الحل، يجب أن تعمل صفحة تسجيل الدخول بشكل طبيعي! 🎉
