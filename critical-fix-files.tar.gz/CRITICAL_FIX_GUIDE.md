# 🚨 دليل الإصلاح الحرج - مشكلة Schema

## ⚠️ المشكلة الحقيقية المكتشفة

بعد التحليل العميق، اتضح أن المشكلة **أكبر بكثير** من مجرد مستخدم مفقود:

### المشكلة الرئيسية:
**تعارض بين MySQL و PostgreSQL في Schema!**

- ✅ المشروع يستخدم **PostgreSQL** (Neon)
- ❌ لكن ملف `schema.ts` كان مكتوباً بصيغة **MySQL**
- 🔥 هذا يسبب أخطاء في أسماء الأعمدة والأنواع

### الأعراض:
1. ❌ خطأ 500 في `siteSettings`
2. ❌ خطأ 401 في تسجيل الدخول
3. ❌ أسماء أعمدة خاطئة (snake_case vs camelCase)

---

## ✅ الحل الذي تم تطبيقه

### 1. تحويل Schema من MySQL إلى PostgreSQL

تم تحديث `drizzle/schema.ts` بالكامل:
- ✅ تغيير من `mysqlTable` إلى `pgTable`
- ✅ تغيير من `mysqlEnum` إلى `pgEnum`
- ✅ تغيير من `int` إلى `integer`
- ✅ استخدام `GENERATED ALWAYS AS IDENTITY` بدلاً من `autoincrement`

### 2. توليد Migrations جديدة

تم توليد ملف migration صحيح: `drizzle/0000_wild_dagger.sql`

### 3. إنشاء SQL Script كامل

تم إنشاء `setup-database-complete.sql` الذي يحتوي على:
- حذف الجداول القديمة
- إنشاء ENUMs
- إنشاء جميع الجداول بالصيغة الصحيحة
- إدراج المستخدم الافتراضي
- إدراج إعدادات الموقع الافتراضية

---

## 🚀 خطوات الإصلاح (مهم جداً!)

### الخيار 1: إعادة بناء قاعدة البيانات بالكامل ⭐ (الموصى به)

#### الخطوة 1: فتح Neon SQL Editor
1. اذهب إلى https://neon.tech
2. سجل الدخول إلى حسابك
3. اختر قاعدة البيانات الخاصة بالمشروع
4. افتح SQL Editor

#### الخطوة 2: تنفيذ SQL Script الكامل
انسخ والصق محتوى ملف `setup-database-complete.sql` بالكامل في SQL Editor ثم اضغط Run.

**هذا سيقوم بـ:**
- ✅ حذف جميع الجداول القديمة
- ✅ إنشاء جميع الجداول بالصيغة الصحيحة
- ✅ إنشاء المستخدم الافتراضي
- ✅ إنشاء إعدادات الموقع الافتراضية

#### الخطوة 3: التحقق من النجاح
يجب أن ترى في النتائج:
```
id | email                    | name          | role        | isActive | createdAt
1  | waleed.qodami@gmail.com  | Waleed Qodami | super_admin | 1        | [timestamp]
```

#### الخطوة 4: نشر Schema المحدث على GitHub
```bash
cd /path/to/build
git add drizzle/schema.ts
git commit -m "Fix: Convert schema from MySQL to PostgreSQL"
git push origin main
```

#### الخطوة 5: إعادة نشر المشروع على Railway
بعد push، Railway سيعيد النشر تلقائياً.

#### الخطوة 6: اختبار تسجيل الدخول
افتح المتصفح وانتقل إلى:
```
https://build-production-09b2.up.railway.app/login
```

استخدم:
- **البريد الإلكتروني:** waleed.qodami@gmail.com
- **كلمة المرور:** 3505490qwE@@

---

### الخيار 2: استخدام Railway CLI (بديل)

إذا كنت تفضل استخدام Railway CLI:

```bash
# 1. تثبيت Railway CLI
npm install -g @railway/cli

# 2. تسجيل الدخول والربط
railway login
cd /path/to/build
railway link

# 3. تشغيل SQL script
railway run psql $DATABASE_URL < setup-database-complete.sql

# 4. التحقق
railway run npx tsx -e "import('./server/auth.js').then(a => a.getAdminByEmail('waleed.qodami@gmail.com').then(console.log))"
```

---

## 📋 ملخص التغييرات

### الملفات المُعدَّلة:
1. ✅ `drizzle/schema.ts` - تحويل كامل من MySQL إلى PostgreSQL
2. ✅ `drizzle/0000_wild_dagger.sql` - migration جديد

### الملفات الجديدة:
1. ✅ `setup-database-complete.sql` - SQL script كامل للإعداد
2. ✅ `drizzle/schema.ts.backup` - نسخة احتياطية من Schema القديم
3. ✅ `CRITICAL_FIX_GUIDE.md` - هذا الدليل

---

## 🔍 التحقق من نجاح الإصلاح

### 1. التحقق من الجداول
```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;
```

يجب أن ترى 14 جدول:
- admins
- blogPosts
- contactMessages
- emailSettings
- homepageSections
- mediaLibrary
- partners
- passwordResetTokens
- projects
- services
- siteSettings
- teamMembers
- testimonials
- users

### 2. التحقق من المستخدم
```sql
SELECT * FROM "admins" WHERE email = 'waleed.qodami@gmail.com';
```

### 3. التحقق من إعدادات الموقع
```sql
SELECT * FROM "siteSettings";
```

يجب أن ترى 5 إعدادات على الأقل.

---

## ⚠️ تحذيرات مهمة

### 1. فقدان البيانات
**تحذير:** تنفيذ `setup-database-complete.sql` سيحذف **جميع البيانات الموجودة**!

إذا كان لديك بيانات مهمة:
1. قم بعمل backup أولاً:
   ```sql
   -- Export existing data before running the script
   ```
2. أو استخدم migration تدريجي بدلاً من DROP/CREATE

### 2. أسماء الأعمدة
Schema الجديد يستخدم **camelCase** لأسماء الأعمدة:
- ✅ `passwordHash` (صحيح)
- ❌ `password_hash` (خطأ)

### 3. ENUMs
تأكد من أن ENUMs تم إنشاؤها قبل الجداول.

---

## 🎯 الخلاصة

### المشكلة الأصلية:
❌ Schema مكتوب بصيغة MySQL بينما المشروع يستخدم PostgreSQL

### الحل:
✅ تحويل Schema بالكامل إلى PostgreSQL وإعادة بناء قاعدة البيانات

### الخطوات المطلوبة:
1. ✅ تنفيذ `setup-database-complete.sql` في Neon
2. ✅ Push التغييرات إلى GitHub
3. ✅ إعادة نشر المشروع على Railway
4. ✅ اختبار تسجيل الدخول

### الوقت المتوقع:
⏱️ 10-15 دقيقة

### مستوى الخطورة:
🔴 حرج - يجب الإصلاح فوراً

---

## 📞 الدعم

إذا واجهت مشاكل:

1. **تحقق من logs في Railway:**
   ```bash
   railway logs
   ```

2. **تحقق من اتصال قاعدة البيانات:**
   ```bash
   railway run psql $DATABASE_URL -c "SELECT version();"
   ```

3. **تحقق من وجود الجداول:**
   ```bash
   railway run psql $DATABASE_URL -c "\dt"
   ```

---

**ملاحظة نهائية:** هذا إصلاح حرج يجب تطبيقه بالكامل. لا تحاول حلول جزئية.

**الحالة:** 🔴 يتطلب إجراء فوري
